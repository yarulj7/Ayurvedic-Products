package com.niit.AyuProducts.Dao;

//import java.util.List;
import com.niit.AyuProducts.Model.Products;

public interface ProductsDao
{
	public boolean saveOrupdate(Products products);
	public boolean delete(Products products);
	public Products getProducts(String id);
//	public List<Products> list();
}