package com.niit.AyuProducts.Model;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Pay")
@Component // to create a default object 
public class Pay 
{
  @Id
   private String pay_id;
   private String paying_way;
   private String status;

   public Pay()
   {
   	this.pay_id="PAY"+UUID.randomUUID().toString().substring(30).toUpperCase();
   }
// Pay ID
     public String getPay_id() 
     {
    	 return pay_id;
     }

     public void setPay_id(String pay_id) 
      {
    	 this.pay_id = pay_id;
      }
 
// Pay Method
     public String getPaying_way() 
      {
         return paying_way;
      }

      public void setPaying_way(String paying_way) 
       {
         this.paying_way = paying_way;
       }

// Pay Status
      public String getStatus() 
       {
          return status;	
       }

       public void setStatus(String status) 
        {
          this.status = status;
        }  
}