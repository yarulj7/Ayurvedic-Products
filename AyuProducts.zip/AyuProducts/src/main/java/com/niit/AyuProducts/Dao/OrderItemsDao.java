package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.OrderItems;

public interface OrderItemsDao 
{
	public boolean saveOrupdate(OrderItems orderItems);
	public boolean delete(OrderItems orderItems);
	public OrderItems getOrderItems(String id);
//	public List<Category> list();
}
