package com.niit.AyuProducts.DaoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.AyuProducts.Dao.CardDao;
import com.niit.AyuProducts.Model.Card;

@Repository("cardDao")
@EnableTransactionManagement
@Transactional
public class CardDaoImpl implements CardDao 
{
	@Autowired
	private SessionFactory sessionFactory;

	public CardDaoImpl(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}

	public boolean saveOrupdate(Card card) 
	{
		try 
		{
			sessionFactory.getCurrentSession().saveOrUpdate(card);
			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return false;
		}
	}

	public boolean delete(Card card) 
	{
			try
			{
			 sessionFactory.getCurrentSession().delete(card);
			 return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				 return false;
			}
	}

//	@Override
	public Card getCard(String id) 
	{
		String s="from Card where cart_Id='" +id +"'";
		Query q=sessionFactory.getCurrentSession().createQuery(s);
		@SuppressWarnings("unchecked")
		List<Card> list=(List<Card>)q.list();
		if(list==null||list.isEmpty()){
		return null;
		}
		else
		{
			return list.get(0);
		}

	}

}
