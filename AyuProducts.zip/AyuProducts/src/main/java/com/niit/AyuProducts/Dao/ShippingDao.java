package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Shipping;

public interface ShippingDao 
{
	public boolean saveOrupdate(Shipping shipping);
	public boolean delete(Shipping shipping);
	public Shipping getShipping(String id);
//	public List<Category> list();
}
