package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Billing;

public interface BillingDao 
{
	public boolean saveOrupdate(Billing billing);
	public boolean delete(Billing billing);
	public Billing getBilling(String id);
//	public List<Category> list();
}
