package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.CartItems;

public interface CartItemsDao 
{
	public boolean saveOrupdate(CartItems cartItems);
	public boolean delete(CartItems cartItems);
	public CartItems getCartItems(String id);
//	public List<Category> list();
}
