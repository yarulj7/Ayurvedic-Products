package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Card;

public interface CardDao 
{
	public boolean saveOrupdate(Card card);
	public boolean delete(Card card);
	public Card getCard(String id);
//	public List<Category> list();
}
