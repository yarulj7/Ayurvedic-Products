package com.niit.AyuProducts.Config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.AyuProducts.Dao.BillingDao;
import com.niit.AyuProducts.Dao.CardDao;
import com.niit.AyuProducts.Dao.CartDao;
import com.niit.AyuProducts.Dao.CartItemsDao;
import com.niit.AyuProducts.Dao.CategoryDao;
import com.niit.AyuProducts.Dao.OrderDao;
import com.niit.AyuProducts.Dao.OrderItemsDao;
import com.niit.AyuProducts.Dao.PayDao;
import com.niit.AyuProducts.Dao.ProductsDao;
import com.niit.AyuProducts.Dao.ShippingDao;
import com.niit.AyuProducts.Dao.SupplierDao;
import com.niit.AyuProducts.Dao.UserDao;
import com.niit.AyuProducts.DaoImpl.BillingDaoImpl;
import com.niit.AyuProducts.DaoImpl.CardDaoImpl;
import com.niit.AyuProducts.DaoImpl.CartDaoImpl;
import com.niit.AyuProducts.DaoImpl.CartItemsDaoImpl;
import com.niit.AyuProducts.DaoImpl.CategoryDaoImpl;
import com.niit.AyuProducts.DaoImpl.OrderDaoImpl;
import com.niit.AyuProducts.DaoImpl.OrderItemsDaoImpl;
import com.niit.AyuProducts.DaoImpl.PayDaoImpl;
import com.niit.AyuProducts.DaoImpl.ProductsDaoImpl;
import com.niit.AyuProducts.DaoImpl.ShippingDaoImpl;
import com.niit.AyuProducts.DaoImpl.SupplierDaoImpl;
import com.niit.AyuProducts.DaoImpl.UserDaoImpl;
import com.niit.AyuProducts.Model.Billing;
import com.niit.AyuProducts.Model.Card;
import com.niit.AyuProducts.Model.Cart;
import com.niit.AyuProducts.Model.CartItems;
import com.niit.AyuProducts.Model.Category;
import com.niit.AyuProducts.Model.Order;
import com.niit.AyuProducts.Model.OrderItems;
import com.niit.AyuProducts.Model.Pay;
import com.niit.AyuProducts.Model.Products;
import com.niit.AyuProducts.Model.Shipping;
import com.niit.AyuProducts.Model.Supplier;
import com.niit.AyuProducts.Model.User;



@Configuration
@ComponentScan("com.niit.*")
@EnableTransactionManagement
public class ApplicationContext 
{

	@Bean("dataSource")
	public DataSource getDataSource() 
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:tcp://localhost/~/AyuProducts");
		dataSource.setUsername("sa");
		dataSource.setPassword("sa");

		// Properties connectionProperties=new Properties();
		// connectionProperties.setProperty("hibernate.show_sql", "true");
		// connectionProperties.setProperty("hibernate.dialect",
		// "org.hibernate.dialect");
		return dataSource;
	}

	private Properties getHibernateProperties() 
	{
		Properties properties = new Properties();
		properties.put("hibernate.connection.pool_size", "10");
		properties.put("hibernate.hbm2ddl.auto", "update");
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		return properties;
	}

	@Autowired
	@Bean("sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) 
	{
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addProperties(getHibernateProperties());
     	sessionBuilder.addAnnotatedClass(Category.class);
     	sessionBuilder.addAnnotatedClass(Products.class);
     	sessionBuilder.addAnnotatedClass(Supplier.class);
		sessionBuilder.addAnnotatedClass(User.class);
		sessionBuilder.addAnnotatedClass(Pay.class);
		sessionBuilder.addAnnotatedClass(Shipping.class);
		sessionBuilder.addAnnotatedClass(Cart.class);
		sessionBuilder.addAnnotatedClass(Billing.class);
		sessionBuilder.addAnnotatedClass(Card.class);
//		sessionBuilder.addAnnotatedClass(Seller.class);
//		sessionBuilder.addAnnotatedClass(Cart.class);
		sessionBuilder.addAnnotatedClass(CartItems.class);
//		sessionBuilder.addAnnotatedClass(Authentication.class);
//		sessionBuilder.addAnnotatedClass(BillingAddress.class);
//		sessionBuilder.addAnnotatedClass(Shipping.class);
//		sessionBuilder.addAnnotatedClass(Pay.class);
//		sessionBuilder.addAnnotatedClass(Card.class);
		sessionBuilder.addAnnotatedClass(Order.class);
        sessionBuilder.addAnnotatedClass(OrderItems.class);
		return sessionBuilder.buildSessionFactory();
	}

	@Autowired
	@Bean("transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) 
	{
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		return transactionManager;
	}
	@Autowired
	@Bean(name="categoryDao")
	public CategoryDao getCategoryDao(SessionFactory sessionFactory) 
	{
		return new CategoryDaoImpl(sessionFactory);
	}
	
	@Autowired
	@Bean(name="productsDao")
	public ProductsDao getProductDao(SessionFactory sessionFactory) 
	{
		return new ProductsDaoImpl(sessionFactory);

	}

	@Autowired
	@Bean(name="supplierDao")
	public SupplierDao getSupplierDao(SessionFactory sessionFactory) 
	{
		return new SupplierDaoImpl(sessionFactory);
	}
	
	@Autowired
	@Bean(name="userDao")
	public UserDao getUserDao(SessionFactory sessionFactory) 
	{
		return new UserDaoImpl(sessionFactory);
	}
	
	@Autowired
	@Bean(name="payDao")
	public PayDao getPayDao(SessionFactory sessionFactory) 
	{
		return new PayDaoImpl(sessionFactory);
	}
	
	@Autowired
	@Bean(name="shippingDao")
	public ShippingDao getShippingDao(SessionFactory sessionFactory) 
	{
		return new ShippingDaoImpl(sessionFactory);
	}

	@Autowired
	@Bean(name="cartDao")
	public CartDao getCartDao(SessionFactory sessionFactory) 
	{
		return new CartDaoImpl(sessionFactory);
	}

	@Autowired
	@Bean(name="billingDao")
	public BillingDao getBillingDao(SessionFactory sessionFactory) 
	{
		return new BillingDaoImpl(sessionFactory);
	}

	@Autowired
	@Bean(name="cardDao")
	public CardDao getCardDao(SessionFactory sessionFactory) 
	{
		return new CardDaoImpl(sessionFactory);
	}

	@Autowired
	@Bean(name="cardItemsDao")
	public CartItemsDao getCardItemsDao(SessionFactory sessionFactory) 
	{
		return new CartItemsDaoImpl(sessionFactory);
	}

	@Autowired
	@Bean(name="orderDao")
	public OrderDao getOrderDao(SessionFactory sessionFactory) 
	{
		return new OrderDaoImpl(sessionFactory);
	}
	
	@Autowired
	@Bean(name="orderItemsDao")
	public OrderItemsDao getOrderItemsDao(SessionFactory sessionFactory) 
	{
		return new OrderItemsDaoImpl(sessionFactory);
	}

	
//	@Autowired
//	@Bean(name="authenticationDao")
//	public AuthenticationDao getAuthenticationDao(SessionFactory sessionFactory) {
//		return new AuthenticationDaoImpl(sessionFactory);
//	}

}