package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Pay;

public interface PayDao 
{
	public boolean saveOrupdate(Pay pay);
	public boolean delete(Pay pay);
	public Pay getPay(String id);
//	public List<Category> list();
}