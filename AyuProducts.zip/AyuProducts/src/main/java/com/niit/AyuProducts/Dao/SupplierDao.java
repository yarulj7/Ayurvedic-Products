package com.niit.AyuProducts.Dao;

//import java.util.List;
import com.niit.AyuProducts.Model.Supplier;

public interface SupplierDao 
{
	public boolean saveOrupdate(Supplier supplier);
	public boolean delete(Supplier supplier);
	public Supplier getSupplier(String id);
//	public List<Supplier> list();
}