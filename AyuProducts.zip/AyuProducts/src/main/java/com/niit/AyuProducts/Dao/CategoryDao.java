package com.niit.AyuProducts.Dao;

//import java.util.List;
import com.niit.AyuProducts.Model.Category;

public interface CategoryDao
{
	public boolean saveOrupdate(Category category);
	public boolean delete(Category category);
	public Category getCategory(String id);
//	public List<Category> list();
}