package com.niit.AyuProducts.DaoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.AyuProducts.Dao.OrderItemsDao;
//import com.niit.AyuProducts.Model.Billing;
import com.niit.AyuProducts.Model.OrderItems;

@Repository(value="orderItemsDao")
@EnableTransactionManagement
@Transactional

public class OrderItemsDaoImpl implements OrderItemsDao
{
	@Autowired
	private SessionFactory sessionFactory;

	public OrderItemsDaoImpl(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}


	public boolean saveOrupdate(OrderItems orderItems) 
	{
		try 
		{
			sessionFactory.getCurrentSession().saveOrUpdate(orderItems);
			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return false;
		}
	}

	public boolean delete(OrderItems orderItems) 
	{
		try
		{
		 sessionFactory.getCurrentSession().delete(orderItems);
		 return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 return false;
		}
	}

	public OrderItems getOrderItems(String id) 
	{
		String s="from OrderItems where orderItem_id='" +id +"'";
		Query q=sessionFactory.getCurrentSession().createQuery(s);
		@SuppressWarnings("unchecked")
		List<OrderItems> list=(List<OrderItems>)q.list();
		if(list==null||list.isEmpty()){
		return null;
		}
		else
		{
			return list.get(0);
		}
	}

}
