package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Cart;

public interface CartDao 
{
	public boolean saveOrupdate(Cart cart);
	public boolean delete(Cart cart);
	public Cart getCart(String id);
//	public List<Category> list();
}