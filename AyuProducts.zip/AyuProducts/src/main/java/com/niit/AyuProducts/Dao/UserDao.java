package com.niit.AyuProducts.Dao;

//import java.util.List;
import com.niit.AyuProducts.Model.User;

 public interface UserDao
 {
	public boolean saveOrupdate(User user);
	public boolean delete(User user);
	public User getUser(String id);
//	public List<User> list();
}