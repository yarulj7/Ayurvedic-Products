package com.niit.AyuProducts.Dao;

import com.niit.AyuProducts.Model.Order;

public interface OrderDao 
{
	public boolean saveOrupdate(Order order);
	public boolean delete(Order order);
	public Order getOrder(String id);
//	public List<Category> list();
}
