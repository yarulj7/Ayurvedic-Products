package com.niit.AyuProducts.Model;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Category")
@Component
public class Category 
{
	@Id
	private String C_Id;
	private String C_Name;
	private String C_Des;
	
	@OneToMany(mappedBy = "category",cascade  = CascadeType.ALL)
	private List<Products> products;
	
	public Category()
	{
    	this.C_Id="CATEGO"+UUID.randomUUID().toString().substring(30).toUpperCase();
	}
// Category Description
	public String getC_Des() 
	{
		return C_Des;
	}

// Category List<Products> products
	public List<Products> getProducts() 
	{
		return products;
	}

	public void setProducts(List<Products> products) 
	{
		this.products = products;
	}

	public void setC_Des(String c_Des) 
	{
		C_Des = c_Des;
	}

	// Category ID
	public String getId() {
		return C_Id;
	}

	public void setId(String id) {
		C_Id = id;
	}

	// Category Name
	public String getName() {
		return C_Name;
	}

	public void setName(String name) {
		C_Name = name;
	}

}
