package com.niit.AyuProducts;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.AyuProducts.Dao.CategoryDao;
import com.niit.AyuProducts.Model.Category;

public class CategoryTest
{
   public static void main(String args[])
   {
      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
      context.scan("com.niit.*");
      context.refresh();
      
     Category category=(Category)context.getBean("category");
     CategoryDao categoryDao=(CategoryDao)context.getBean("categoryDao"); 
     
     category.setId("1A");
     category.setName("Juice");
     category.setC_Des("It is good for health");

    if(categoryDao.saveOrupdate(category))
    {
    	System.out.println("\t  ============= Saved Sucessfully the new Category "+category.getName());
    }
    else
    	System.out.println("\t  ============= Failed to  Save Category "+category.getName());
    
    
//    if(categoryDao.delete(category))
//    {
//    	System.out.println("\t  ============= Sucessfully  Deleted  Category ");
//    }
//    else
//    	System.out.println("\t  ============= Failed to Delete the Category ");
//  THE CATEGORY WILL ONLY DELETE WHEN THE CATEGORY IS NOT LINKED ANY WHERE IN THE DATABASE   

    
    Category category2 = categoryDao.getCategory("1A");
     if(category2 == null )
     {
    	 System.out.println("\t Sorry Category Not Found ");
     }
     
     else
     {
    	 System.out.println("Category Name = "+category2.getName());
     }
    
    context.close();
	}
 
    
      
   }