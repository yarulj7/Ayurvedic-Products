package com.niit.AyuProducts;

public class ShippingTest 
{
	public static void main(String[] args)
	{

	}

}
